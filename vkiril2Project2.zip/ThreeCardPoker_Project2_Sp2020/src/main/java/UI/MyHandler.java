package UI;

/*
    Used as a lambda function interface to pass into functions
 */

public interface MyHandler {
    void run(int value);
}