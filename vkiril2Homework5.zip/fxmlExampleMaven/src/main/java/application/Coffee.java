package application;

public interface Coffee {
    double makeCoffee();
    static String getText() {
        return "empty text";
    };
}
