import java.util.Iterator;

// Iterator interface
interface CreateIterator<T> {
    Iterator<T> createIterator();
}