/*
	Viktor Kirillov
 	vkiril2@uic.edu
	My own versions of the stack and queue data structures.
*/

import java.util.ArrayList;
import java.util.Iterator;

public class GLProject {

	// Returns all values in an ArrayList
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello generic lists");
	}

}
