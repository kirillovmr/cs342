import java.util.Iterator;

// Iterator interface
interface CreateIterator {
    Iterator createIterator();
}