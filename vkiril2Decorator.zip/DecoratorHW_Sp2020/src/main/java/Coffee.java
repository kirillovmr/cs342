import javafx.scene.text.Text;

public interface Coffee {
	public double makeCoffee();
	public static String getText() {
		return "empty text";
	};
}
