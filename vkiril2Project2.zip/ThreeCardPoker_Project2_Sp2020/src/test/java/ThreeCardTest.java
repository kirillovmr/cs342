
import org.junit.jupiter.api.Test;

class ThreeCardTest {

	@Test
	void test() {

	}

}
